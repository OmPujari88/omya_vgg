// Copyright 2021 Google Inc. All Rights Reserved.
// This file is available under the Apache license.
//go:build race
// +build race

package testutil

const RaceDetectorMultiplier = 30.0
